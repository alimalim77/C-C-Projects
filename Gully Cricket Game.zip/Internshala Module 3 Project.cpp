/* Course: Intrenshala
Topic: CPP Module 3
Project: Gully Cricket App*/

#include<iostream>
#include<cstdlib>
#include<ctime>
#include<unistd.h>


using namespace std;

string curBtsm,curbowl;
class Team
{
	public:
		string Tname;
		string players[3];
		int TotR;

};

void welcomeUser()
{
   cout<<"----------------********************Welcome To The Gully Cricket App***********************----------------------"<<endl;

}

void displayPlayers(string Players1[],string Players2[])
{
    cout<<"Members of team A are :>\n"<<endl;
    for(int i=0;i<3;i++)
        cout<<Players1[i]<<endl;

    cout<<"\nMembers of team B are :>\n"<<endl;
    for(int j=0;j<3;j++)
        cout<<Players2[j]<<endl;

}

void selectBatsmanAndBowler(string Players1[],string Players2[])
{
    int num1,num2;

     num1=rand()%3;


     curBtsm=Players1[num1];
     num2=rand()%3;


     curbowl=Players2[num2];

}

void startInning(int inning,Team T1,Team T2)
{
    cout<<"\nThe inning is :>"<<inning<<endl;
    cout<<curBtsm<<" from  " <<T1.Tname<<" is Batting" <<endl;
    cout<<curbowl<<" from "<<T2.Tname<<"  is Bowling" <<endl;

}

int playInning()
{

    int total=0;
    for(int i=0;i<6;i++)
    {

     total+=rand()%7;
    }

    return total;
}

void decideWinner(int TaS,int TbS)
{
    if(TaS>TbS)
    {
        cout<<"\n Team_A defeated Team_B by :"<<TaS-TbS<<" runs.";
    }
    else if (TaS<TbS)
    {
        cout<<"\n Team_B defeated Team_A by :"<<TbS-TaS<<" runs.";

    }
    else{
        cout<<" \n score is equal ....... match is Drawn.";
    }
}

int main()
{
    welcomeUser();

	Team t1 ,t2;
	cout<<"Enter Team names:>\n\n"<<endl;
	t1.Tname="Team_A";
	t2.Tname="Team_B";

	t1.players[0]="Virat";
	t1.players[1]="Rohit";
	t1.players[2]="Bravo";


    t2.players[0]="Dhoni";
	t2.players[1]="Stokes";
	t2.players[2]="Rabada";
	displayPlayers(t1.players,t2.players);
    srand(time(0));

	int inn=1,total1,total2;



      selectBatsmanAndBowler(t1.players,t2.players);
	  startInning(inn,t1,t2);
      total1=playInning();
      cout<<"Score is "<<total1<<endl;
      inn++;
      usleep(3000000);
      selectBatsmanAndBowler(t2.players,t1.players);
	  startInning(inn,t2,t1);
      total2=playInning();
      cout<<"Score is "<<total2<<endl;
      usleep(3000000);

      decideWinner(total1,total2);




	return 0;
}
