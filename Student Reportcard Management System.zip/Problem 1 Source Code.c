//---***WELCOME***---
//It is a computer generated report card
// Enter the details to find your grade

#include<stdio.h>
#include<unistd.h>

int main()
{
char name[50], sec;
int standard;
int eng,hin,math,sci,sst,sum=0;
char grade;

/* Input of Mandatory Details*/
printf("Enter the Name Class and Section of sudent:\n");
puts("Name:");
scanf("%[^\n]%*c", name);
puts("Standard:");
scanf("%d",&standard);
fflush(stdin);
puts("Section:");
scanf("%c", &sec);
while((getchar()) != '\n'); // As told in Internshala lesson

/* Input of Marks Obtained*/

puts("Enter the marks obtained by student in:\nEnglish\nHindi\nMathematics\nScience\nSocialStudies\n");
scanf("%d%d%d%d%d",&eng,&hin,&math,&sci,&sst);
sum=eng+hin+math+sci+sst;
printf("Total Marks Obatained: %d\n", sum);
if(sum >=450 && sum<=500)
	grade='A';
else if (sum >=400 && sum<450)
	grade='B';
else if (sum >= 350 && sum<400)
	grade='C';
else if (sum >=300 && sum<350)
	grade='D';
else if (sum >=200 && sum<300)
	grade='E';
else if (sum >=0 && sum<200)
	grade='F';
else
	exit(0);
printf("Grade Obtained is %c", grade);
//Final Output
puts("\nPlease Wait While Your Report Card Gets Generated");
usleep(4000000);
printf("\n-------------------------------------------------------------------\n");
printf("\tDr. Virendra Swarup Memorial Public School\n");
printf("\t\tAnnual Report\n");
printf("\tName: %s \n\tStandard: %d\n\tSection: %c\n", name, standard, sec);
printf("\n\n\tMarks Obtainened In Exams\n");
printf("\tEnglish:%d\n\tHindi:%d\n\tMathematics:%d\n\tScience:%d\n\tSocial Studies:%d\n", eng, hin, math, sci,sst);
printf("\tTotal Marks Secured:%d\n\tGrade:%c", sum, grade);

return 0;
}







